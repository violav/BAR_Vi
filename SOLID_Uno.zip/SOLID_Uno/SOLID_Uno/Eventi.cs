﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_Uno
{
    public class Eventi : BaseClass
    {
        public void ApprovvigionaBevande()
        {
            utils.ApprovvigionamentoBevande();
        }
        public void ReclutaPersonale()
        {
            utils.ReclutaPersonale();
        }
    }
}
