﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_Uno
{
    public class Utils
    {
        public void ApprovvigionamentoBevande()
        {
            Bevanda bev = new Bevanda(1);
            //..
        }
        public void ReclutaPersonale()
        {
            Personale pers = new Personale(1);
            //..
        }
    }
}
