﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
private InterrogazioneDati _interrogazioneDati;


//SOLID
//Single responsability

